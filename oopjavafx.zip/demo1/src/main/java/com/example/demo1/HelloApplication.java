

package com.example.demo1;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;

public class HelloApplication extends Application {

    private final ArrayList<String> dataList = new ArrayList<>();

    @Override
    public void start(Stage stage) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        Image bannerImage = new Image("file:C:/Users/IT-LINKS/IdeaProjects/demo1/src/main/resources/com/example/image/pic.png");
        if (bannerImage.isError()) {
            System.out.println("Error loading image: " + bannerImage.getException());
        }
        ImageView imageView = new ImageView(bannerImage);
        imageView.setFitWidth(750);
        imageView.setFitHeight(300);
        imageView.setPreserveRatio(false);

        TextField nameField = new TextField();
        Label nameLabel = new Label("Name:");
        HBox nameBox = createStyledBox(nameLabel, nameField);

        TextField fatherNameField = new TextField();
        Label fatherNameLabel = new Label("Father Name:");
        HBox fatherNameBox = createStyledBox(fatherNameLabel, fatherNameField);

        ComboBox<String> cityComboBox = new ComboBox<>();
        cityComboBox.getItems().addAll("Lahore", "Islamabad", "Karachi", "Multan");
        cityComboBox.setValue("Lahore");
        Label cityLabel = new Label("City:");
        HBox cityBox = createStyledBox(cityLabel, cityComboBox);

        TextField addressField = new TextField();
        Label addressLabel = new Label("Address:");
        HBox addressBox = createStyledBox(addressLabel, addressField);

        TextField emailField = new TextField();
        Label emailLabel = new Label("Email:");
        HBox emailBox = createStyledBox(emailLabel, emailField);

        HBox fileBox = new HBox(10);
        Label fileLabel = new Label("Image:");
        Button fileButton = new Button("Choose File");
        final ImageView chosenImageView = new ImageView();

        fileButton.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            File selectedFile = fileChooser.showOpenDialog(stage);
            if (selectedFile != null) {
                Image image = new Image("file:" + selectedFile.getAbsolutePath());
                chosenImageView.setImage(image);
                chosenImageView.setFitHeight(100);
                chosenImageView.setFitWidth(100);
            }
        });
        fileBox.getChildren().addAll(fileLabel, fileButton);

        HBox genderBox = new HBox(10);
        Label genderLabel = new Label("Gender:");
        ToggleGroup genderGroup = new ToggleGroup();
        RadioButton maleRadio = new RadioButton("Male");
        maleRadio.setToggleGroup(genderGroup);
        RadioButton femaleRadio = new RadioButton("Female");
        femaleRadio.setToggleGroup(genderGroup);
        genderBox.getChildren().addAll(genderLabel, maleRadio, femaleRadio);
        genderBox.setPadding(new Insets(10));

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(event -> {String name = nameField.getText();
            String fatherName = fatherNameField.getText();
            String city = cityComboBox.getValue();
            String address = addressField.getText();
            String email = emailField.getText();
            String gender = ((RadioButton) genderGroup.getSelectedToggle()).getText();

            dataList.add("Name: " + name + ", Father Name: " + fatherName + ", City: " + city
                    + ", Address: " + address + ", Email: " + email + ", Gender: " + gender);

            Label displayLabel = new Label("Submitted Data:\n" + dataList.get(dataList.size() - 1));
            VBox displayLayout = new VBox(10, displayLabel);
            displayLayout.setPadding(new Insets(20));
            Scene displayScene = new Scene(displayLayout, 400, 300);
            Stage displayStage = new Stage();
            displayStage.setTitle("Submitted Data");
            displayStage.setScene(displayScene);
            displayStage.show();
        });
        layout.getChildren().addAll(imageView, nameBox, fatherNameBox, cityBox, addressBox, emailBox, fileBox, genderBox, submitButton, chosenImageView);

        Scene scene = new Scene(layout, 800, 900);
        stage.setTitle("Data Entry Form");
        stage.setScene(scene);
        stage.show();
    }

    private HBox createStyledBox(Label label, Control control) {
        HBox box = new HBox(10);
        box.setPadding(new Insets(10));
        box.setSpacing(10);
        box.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1))));
        box.getChildren().addAll(label, control);
        return box;
    }

    public static void main(String[] args) {
        launch();
    }
}